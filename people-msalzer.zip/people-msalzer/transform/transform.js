/**
 **
 **  const zoos = {
 **    lincolnParkZoo: [
 **      {class: 'Mammal', name: 'Kangaroo'},
 **      {class: 'Reptile', name: 'Crocodile'},
 **      …
 **    ],
 **    sanDiegoZoo: [
 **      {class: 'Bird', name: 'Penguin'},
 **      {class: 'Mammal', name: 'Tiger'},
 **      …
 **    ],
 **    detroitZoo: [
 **      {class: 'Fish', name: 'Clown Fish'},
 **      {class: 'Amphibian', name: 'Salamander'},
 **      …
 **    ],
 **    …
 **  }
 **
 **/

// Transform the "zoos" object so that animals across every zoo are organized
// by "class" and alphabetized by "name". Try to make the transformation
// efficient as you may have to manipulate a very large dataset.
//
// The result should be an object with a single key for each distinct animal
// class within the dataset (mammal, reptile, bird, etc.) Each of these class
// keys should map to a list of name strings for animals of that class. These
// lists may or may not contain duplicates and should be alphabetized
// from "A" to "z".

const zoos = {
    "lincolnParkZoo": [
        {"class": "Mammal", "name": "Kangaroo"},
        {"class": "Reptile", "name": "Crocodile"},
        {"class": "Reptile", "name": "Checkered Garter Snake"},
        {"class": "Fish", "name": "Salmon"},
        {"class": "Fish", "name": "Tuna"},
        {"class": "Bird", "name": "Green Hummingbird"}
    ],
    "sanDiegoZoo": [
        {"class": "Bird", "name": "Penguin"},
        {"class": "Mammal", "name": "Tiger"},
        {"class": "Mammal", "name": "Cat"},
        {"class": "Mammal", "name": "Dog"},
        {"class": "Mammal", "name": "Pig"},
        {"class": "Mammal", "name": "Horse"},
        {"class": "Mammal", "name": "Sheep"},
        {"class": "Reptile", "name": "Lizard"},
        {"class": "Reptile", "name": "San Francisco Garter Snake"}
    ],
    "detroitZoo": [
        {"class": "Fish", "name": "Clown Fish"},
        {"class": "Amphibian", "name": "Salamander"},
        {"class": "Reptile", "name": "Texas Garter Snake"},
        {"class": "Reptile", "name": "Common Garter Snake"},
        {"class": "Bird", "name": "Red Hummingbird"},
        {"class": "Bird", "name": "Blue Hummingbird"}
    ],
    "chicagoZoo": [
        {"class": "Reptile", "name": "Crocodile"},
        {"class": "Reptile", "name": "Checkered Garter Snake"}
    ],
    "emptyZoo": []
}

// sorts and removes duplicates
function quickSortBasic(array) {
    if(array.length < 2) {
        return array;
    }
    var pivot = array[0];
    var lesserArray = [];
    var greaterArray = [];
    for (var i = 1; i < array.length; i++) {
        if ( array[i] > pivot ) {
            greaterArray.push(array[i]);
        } else if ( array[i] < pivot ){
            lesserArray.push(array[i]);
        } // if array[i] === pivot do nothing because it's a duplicate
    }
    return quickSortBasic(lesserArray).concat(pivot, quickSortBasic(greaterArray));
}


let animalbyclass = {};

// group animals by class
for (let zoo in zoos) {
    zoos[zoo].forEach(element => {
        let animalClass = element.class;
        let animalName = element.name;
        if (animalbyclass[animalClass] ) {
            let animArr = animalbyclass[animalClass];
            animArr.push(animalName);
            animalbyclass[animalClass] = animArr;
        } else {
            animalbyclass[animalClass] = [element.name];
        }
    });
}

// send each animal array to be sorted and deduped
for (let animalGroup in animalbyclass) {
    let array = animalbyclass[animalGroup];
    animalbyclass[animalGroup] = quickSortBasic(array);
}

// the end result is animalbyclass




